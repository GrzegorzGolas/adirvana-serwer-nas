## Automated install script

Repo contains bootstrap script:

```bash
sudo bash scripts/install-audio-server.sh
```

Script configures:

- Debian RT kernel packages
- sysctl audio tuning
- GRUB kernel parameters
- Audirvana systemd service
- Avahi discovery
- SMB / NFS music sharing
- persistent NIC tuning (`ethtool`)

Detailed notes:

- [`docs/install-script-usage.md`](docs/install-script-usage.md)
